import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_maps_place_picker/google_maps_place_picker.dart';
import 'package:places_app/helpers/location_helper.dart';
import 'package:places_app/models/place.dart';

class MapScreen extends StatefulWidget {
  final PlaceLocation initialLocation;
  final isSelection;

  MapScreen(this.initialLocation, {this.isSelection = false});

  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  PickResult _pickedLocation;

  void _selectLocation(PickResult position) {
    setState(() {
      _pickedLocation = position;
    });
  }

  @override
  Widget build(BuildContext context) {
    final deviceWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      // appBar: AppBar(
      //   title: Text('Your Map'),
      //   actions: [
      //     if (widget.isSelection)
      //       IconButton(
      //         icon: Icon(Icons.check),
      //         onPressed: () {
      //           Navigator.of(context).pop(LatLng(
      //               _pickedLocation.geometry.location.lat,
      //               _pickedLocation.geometry.location.lat));
      //         },
      //       )
      //   ],
      // ),
      body: PlacePicker(
        apiKey: GOOGLE_API_KEY,
        //forceSearchOnZoomChanged: true,
        //automaticallyImplyAppBarLeading: false,
        //autocompleteLanguage: "ko",
        //region: 'au',
        //selectInitialPosition: true,
        selectedPlaceWidgetBuilder:
            (_, selectedPlace, state, isSearchBarFocused) {
          print("state: $state, isSearchBarFocused: $isSearchBarFocused");
           return isSearchBarFocused
                                ? Container()
                                : FloatingCard(
                                    bottomPosition: 0.0, // MediaQuery.of(context) will cause rebuild. See MediaQuery document for the information.
                                    leftPosition: 0.0,
                                    rightPosition: 0.0,
                                    width: deviceWidth,
                                    child: state == SearchingState.Searching
                                        ? Center(child: CircularProgressIndicator())
                                        : RaisedButton(
                                            child: Text("Pick Here"),
                                            onPressed: () {
                                              // IMPORTANT: You MUST manage selectedPlace data yourself as using this build will not invoke onPlacePicker as
                                              //            this will override default 'Select here' Button.
                                              print("do something with [selectedPlace] data");
                                              Navigator.of(context).pop();
                                            },
                                          ),
                                  );
        },
        useCurrentLocation: true,
        selectInitialPosition: true,
        initialPosition: LatLng(
            widget.initialLocation.latitude, widget.initialLocation.longitude),
        onPlacePicked: widget.isSelection ? _selectLocation : null,
      ),
    );
  }
}
